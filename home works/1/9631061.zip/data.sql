
-- --------------------------------------------------------

INSERT INTO `drivers` (`id`, `first_name`, `last_name`, `status`, `phone`) VALUES
(0, 'Parham', 'Alvani', 0, '09127024197'),
(1, 'Ehsan', 'Edalat', 0, '0912724195'),
(2, 'Mahdi', 'Ahmadpanah', 0, '09127024193'),
(3, 'Ahmad', 'Asadi', 0, '09127024191'),
(4, 'Bahador', 'Bakhshi', 0, '09127024189');

-- --------------------------------------------------------

INSERT INTO `passengers` (`id`, `first_name`, `last_name`, `phone`) VALUES
(0, 'Mohmmad', 'Mozaffari', '09125108621'),
(1, 'Hasan', 'Khandan', '09125108623'),
(2, 'Ali', 'Shademan', '09125108625'),
(3, 'Valid', 'Zahek', '09125108627');

-- --------------------------------------------------------

